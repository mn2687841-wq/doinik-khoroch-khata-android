package com.najat.doinikkhoroch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 401;
    private static final int OPEN_FILE = 402;
    private WebView webView;
    private String pendingFileName;
    private byte[] pendingFileBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF101827);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppBridge(this), "AndroidApp");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AppBridge {
        private final Context context;
        AppBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void checkForUpdate(String callbackName) {
            new Thread(() -> {
                String result;
                HttpURLConnection connection = null;
                try {
                    URL url = new URL("https://api.github.com/repos/mn2687841-wq/doinik-khoroch-khata-android/releases/latest");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    int code = connection.getResponseCode();
                    if (code != 200) throw new Exception("No published release");
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    try (InputStream in = connection.getInputStream()) {
                        byte[] buffer = new byte[4096]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    }
                    org.json.JSONObject release = new org.json.JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
                    String tag = release.optString("tag_name", "").replaceFirst("^[vV]", "");
                    String releaseUrl = release.optString("html_url", "https://github.com/mn2687841-wq/doinik-khoroch-khata-android/releases");
                    org.json.JSONObject response = new org.json.JSONObject();
                    response.put("version", tag);
                    response.put("url", releaseUrl);
                    response.put("available", isNewerVersion(tag, "1.0"));
                    result = response.toString();
                } catch (Exception e) {
                    try { result = new org.json.JSONObject().put("error", "আপডেট পরীক্ষা করা যায়নি। ইন্টারনেট সংযোগ বা প্রকাশিত নতুন সংস্করণ পরীক্ষা করুন।").toString(); }
                    catch (Exception ignored) { result = "{}"; }
                } finally { if (connection != null) connection.disconnect(); }
                final String json = result;
                runOnUiThread(() -> webView.evaluateJavascript(callbackName + "(" + org.json.JSONObject.quote(json) + ")", null));
            }).start();
        }

        @JavascriptInterface
        public void openUpdatePage() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/mn2687841-wq/doinik-khoroch-khata-android/releases/latest"));
                startActivity(intent);
            });
        }

        private boolean isNewerVersion(String latest, String current) {
            try {
                String[] a = latest.split("\\."), b = current.split("\\.");
                for (int i = 0; i < Math.max(a.length, b.length); i++) {
                    int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9].*$", "")) : 0;
                    int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9].*$", "")) : 0;
                    if (x != y) return x > y;
                }
            } catch (Exception ignored) { }
            return false;
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("DoinikKhorochKhata");
                    pm.print("দৈনিক খরচের খাতা", adapter,
                        new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "প্রিন্ট চালু করা যায়নি", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String base64) {
            runOnUiThread(() -> {
                try {
                    pendingFileName = name;
                    pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(name.toLowerCase().endsWith(".csv") ? "text/csv" : "application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ফাইল সংরক্ষণের অনুরোধ চালু করা যায়নি", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void chooseBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                startActivityForResult(intent, OPEN_FILE);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_FILE && pendingFileBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open output");
                    out.write(pendingFileBytes);
                    out.flush();
                }
                pendingFileBytes = null;
                Toast.makeText(this, "ফাইল সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_FILE) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Unable to open input");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                String quoted = org.json.JSONObject.quote(json);
                webView.evaluateJavascript("window.importBackupFromAndroid(" + quoted + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "ফাইলটি পড়া বা সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
