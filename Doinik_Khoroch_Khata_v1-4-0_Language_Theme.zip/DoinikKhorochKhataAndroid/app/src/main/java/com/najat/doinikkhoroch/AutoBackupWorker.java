package com.najat.doinikkhoroch;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AutoBackupWorker extends Worker {
    public static final String PREFS = "auto_backup";
    public static final String PHONE_TREE = "phone_tree_uri";
    public static final String DRIVE_TREE = "drive_tree_uri";
    public static final String STATUS = "last_backup_status";
    public static final String LAST_PHONE = "last_phone_backup";
    public static final String LAST_DRIVE = "last_drive_backup";
    public static final String SNAPSHOT_FILE = "latest_backup.json";
    public static final String TARGET = "target";
    public static final String PHONE = "phone";
    public static final String DRIVE = "drive";

    public AutoBackupWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = getInputData().getString(TARGET);
        if (target == null) target = PHONE;
        String tree = prefs.getString(PHONE.equals(target) ? PHONE_TREE : DRIVE_TREE, null);
        if (tree == null || tree.isEmpty()) {
            prefs.edit().putString(STATUS, PHONE.equals(target)
                    ? "ফোনের ব্যাকআপ ফোল্ডার নির্বাচন করা হয়নি।"
                    : "Google Drive ব্যাকআপ ফোল্ডার নির্বাচন করা হয়নি।").apply();
            return Result.success();
        }

        File snapshot = new File(context.getFilesDir(), SNAPSHOT_FILE);
        if (!snapshot.isFile() || snapshot.length() == 0) {
            prefs.edit().putString(STATUS, "এখনো ব্যাকআপ করার মতো নতুন হিসাব পাওয়া যায়নি।").apply();
            return Result.success();
        }

        try {
            Uri treeUri = Uri.parse(tree);
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            String fileName = "Doinik-Khoroch-Khata-" + date + ".json";
            Uri folder = DocumentsContract.buildDocumentUriUsingTree(
                    treeUri, DocumentsContract.getTreeDocumentId(treeUri));
            String mime = "application/json";
            Uri existing = findChild(context, treeUri, folder, fileName);
            if (existing != null) {
                try { DocumentsContract.deleteDocument(context.getContentResolver(), existing); }
                catch (Exception ignored) { }
            }
            Uri created = DocumentsContract.createDocument(context.getContentResolver(), folder, mime, fileName);
            if (created == null) throw new Exception("ফোল্ডারে ব্যাকআপ ফাইল তৈরি করা যায়নি।");
            try (InputStream in = new FileInputStream(snapshot);
                 OutputStream out = context.getContentResolver().openOutputStream(created, "w")) {
                if (out == null) throw new Exception("ব্যাকআপ ফাইলে লেখা যায়নি।");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                out.flush();
            }
            String now = new SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault()).format(new Date());
            SharedPreferences.Editor edit = prefs.edit();
            if (PHONE.equals(target)) edit.putString(LAST_PHONE, now);
            else edit.putString(LAST_DRIVE, now);
            edit.putString(STATUS, PHONE.equals(target)
                    ? "ফোনে সর্বশেষ ব্যাকআপ সম্পন্ন: " + now
                    : "Google Drive-এ সর্বশেষ ব্যাকআপ সম্পন্ন: " + now);
            edit.apply();
            return Result.success();
        } catch (SecurityException e) {
            prefs.edit().putString(STATUS, "ব্যাকআপ ফোল্ডারের অনুমতি নেই। সেটিংস থেকে ফোল্ডার আবার নির্বাচন করুন।").apply();
            return Result.failure();
        } catch (Exception e) {
            prefs.edit().putString(STATUS, (PHONE.equals(target) ? "ফোনে" : "Google Drive-এ")
                    + " ব্যাকআপ সম্পন্ন হয়নি; পরে আবার চেষ্টা হবে।").apply();
            return Result.retry();
        }
    }

    private Uri findChild(Context context, Uri treeUri, Uri folder, String wantedName) {
        String parentId = DocumentsContract.getDocumentId(folder);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
        String[] projection = new String[] {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
        };
        try (Cursor cursor = context.getContentResolver().query(children, projection, null, null, null)) {
            if (cursor == null) return null;
            int idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            while (cursor.moveToNext()) {
                if (wantedName.equals(cursor.getString(nameCol))) {
                    return DocumentsContract.buildDocumentUriUsingTree(treeUri, cursor.getString(idCol));
                }
            }
        } catch (Exception ignored) { }
        return null;
    }
}
