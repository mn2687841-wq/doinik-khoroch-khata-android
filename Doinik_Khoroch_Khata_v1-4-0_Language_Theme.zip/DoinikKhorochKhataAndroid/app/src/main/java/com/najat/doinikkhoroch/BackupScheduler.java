package com.najat.doinikkhoroch;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class BackupScheduler {
    private BackupScheduler() { }

    public static void scheduleDaily(Context context) {
        Constraints phoneConstraints = new Constraints.Builder().build();
        PeriodicWorkRequest phone = new PeriodicWorkRequest.Builder(
                AutoBackupWorker.class, 24, TimeUnit.HOURS)
                .setInputData(new Data.Builder().putString(AutoBackupWorker.TARGET, AutoBackupWorker.PHONE).build())
                .setConstraints(phoneConstraints)
                .build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "daily-phone-backup", ExistingPeriodicWorkPolicy.KEEP, phone);

        Constraints driveConstraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest drive = new PeriodicWorkRequest.Builder(
                AutoBackupWorker.class, 24, TimeUnit.HOURS)
                .setInputData(new Data.Builder().putString(AutoBackupWorker.TARGET, AutoBackupWorker.DRIVE).build())
                .setConstraints(driveConstraints)
                .build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "daily-drive-backup", ExistingPeriodicWorkPolicy.KEEP, drive);
    }

    public static void runNow(Context context) {
        OneTimeWorkRequest phone = new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
                .setInputData(new Data.Builder().putString(AutoBackupWorker.TARGET, AutoBackupWorker.PHONE).build())
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(
                "manual-phone-backup", ExistingWorkPolicy.REPLACE, phone);

        Constraints network = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest drive = new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
                .setConstraints(network)
                .setInputData(new Data.Builder().putString(AutoBackupWorker.TARGET, AutoBackupWorker.DRIVE).build())
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(
                "manual-drive-backup", ExistingWorkPolicy.REPLACE, drive);
    }

    public static void syncDriveWhenOnline(Context context) {
        Constraints network = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest drive = new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
                .setConstraints(network)
                .setInputData(new Data.Builder().putString(AutoBackupWorker.TARGET, AutoBackupWorker.DRIVE).build())
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(
                "pending-drive-backup", ExistingWorkPolicy.KEEP, drive);
    }
}
