দৈনিক খরচের খাতা — Android Project

এই সংস্করণে:
- App Icon আপডেট
- GitHub Releases API দিয়ে সর্বশেষ সংস্করণ পরীক্ষা
- GitHub Release-এর APK সরাসরি DownloadManager দিয়ে ডাউনলোড
- ডাউনলোড শেষে Android-এর স্বাভাবিক APK installer চালু
- Android-এর অজানা উৎস থেকে ইনস্টল অনুমতি ব্যবহারকারীকেই দিতে হবে

Package: com.najat.doinikkhoroch
versionCode: 2
versionName: 1.2.1

গুরুত্বপূর্ণ:
1. আগের APK-এর একই signing keystore ব্যবহার করতে হবে।
2. এই Project থেকে তৈরি APK-টি প্রথমে GitHub Release v1.2.1-এ প্রকাশ করতে হবে।
3. এরপর অ্যাপের ভেতরের updater ভবিষ্যতের v1.2.2 বা তার বেশি সংস্করণ ডাউনলোড করতে পারবে।
4. GitHub Release-এ APK asset থাকতে হবে।
5. অ্যাপের হিসাব localStorage key dailyExpenseLedgerBn_v1-এ থাকে; এই key বা WebView origin পরিবর্তন করবেন না।
6. APK Build এবং ফোনে পরীক্ষা না করে updater-কে কার্যকর ধরে নেবেন না।
