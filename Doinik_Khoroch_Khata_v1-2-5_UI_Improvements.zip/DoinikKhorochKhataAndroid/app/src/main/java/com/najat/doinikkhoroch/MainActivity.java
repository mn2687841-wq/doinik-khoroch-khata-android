package com.najat.doinikkhoroch;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 401;
    private static final int OPEN_FILE = 402;
    private WebView webView;
    private String pendingFileName;
    private byte[] pendingFileBytes;
    private long activeDownloadId = -1;
    private Uri pendingApkUri;
    private BroadcastReceiver downloadReceiver;
    private static final String PREFS = "app_update";
    private static final String PREF_PENDING_URI = "pending_apk_uri";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerDownloadReceiver();
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF101827);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppBridge(this), "AndroidApp");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AppBridge {
        private final Context context;
        AppBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void checkForUpdate(String callbackName) {
            // Always report a visible result to the WebView, including when no GitHub
            // Release has been published yet. Never silently leave the button spinning.
            new Thread(() -> {
                String result;
                HttpURLConnection connection = null;
                try {
                    URL url = new URL("https://api.github.com/repos/mn2687841-wq/doinik-khoroch-khata-android/releases/latest");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("User-Agent", "Doinik-Khoroch-Khata-Android");
                    int code = connection.getResponseCode();
                    org.json.JSONObject response = new org.json.JSONObject();
                    if (code == 404) {
                        response.put("error", "এখনো GitHub-এ নতুন সংস্করণের Release প্রকাশ করা হয়নি। Release প্রকাশের পর আবার পরীক্ষা করুন।");
                    } else if (code != 200) {
                        response.put("error", "GitHub থেকে তথ্য পাওয়া যায়নি (HTTP " + code + ")। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");
                    } else {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (InputStream in = connection.getInputStream()) {
                            byte[] buffer = new byte[4096]; int n;
                            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        }
                        org.json.JSONObject release = new org.json.JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
                        String tag = release.optString("tag_name", "").replaceFirst("^[vV]", "");
                        String releaseUrl = release.optString("html_url", "https://github.com/mn2687841-wq/doinik-khoroch-khata-android/releases/latest");
                        response.put("version", tag);
                        response.put("url", releaseUrl);
                        String apkUrl = "";
                        org.json.JSONArray assets = release.optJSONArray("assets");
                        if (assets != null) {
                            for (int i = 0; i < assets.length(); i++) {
                                org.json.JSONObject asset = assets.optJSONObject(i);
                                if (asset != null && asset.optString("name").toLowerCase().endsWith(".apk")) {
                                    apkUrl = asset.optString("browser_download_url");
                                    break;
                                }
                            }
                        }
                        response.put("apkUrl", apkUrl);
                        String currentVersion = BuildConfig.VERSION_NAME;
                        response.put("currentVersion", currentVersion);
                        response.put("available", !apkUrl.isEmpty() && isNewerVersion(tag, currentVersion));
                        if (apkUrl.isEmpty()) response.put("error", "সর্বশেষ Release-এ APK ফাইল পাওয়া যায়নি।");
                        else if (!response.optBoolean("available")) response.put("message", "আপনার অ্যাপ সর্বশেষ প্রকাশিত সংস্করণে আছে (" + currentVersion + ")।");
                    }
                    result = response.toString();
                } catch (Exception e) {
                    try { result = new org.json.JSONObject().put("error", "আপডেট পরীক্ষা করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।").toString(); }
                    catch (Exception ignored) { result = "{}"; }
                } finally { if (connection != null) connection.disconnect(); }
                final String json = result;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.showUpdateResult(" + org.json.JSONObject.quote(json) + ")", null);
                });
            }).start();
        }

        @JavascriptInterface
        public void downloadUpdate(String apkUrl) {
            runOnUiThread(() -> startApkDownload(apkUrl));
        }

        private boolean isNewerVersion(String latest, String current) {
            try {
                String[] a = latest.split("\\."), b = current.split("\\.");
                for (int i = 0; i < Math.max(a.length, b.length); i++) {
                    int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9].*$", "")) : 0;
                    int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9].*$", "")) : 0;
                    if (x != y) return x > y;
                }
            } catch (Exception ignored) { }
            return false;
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("DoinikKhorochKhata");
                    pm.print("দৈনিক খরচের খাতা", adapter,
                        new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "প্রিন্ট চালু করা যায়নি", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String base64) {
            runOnUiThread(() -> {
                try {
                    pendingFileName = name;
                    pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(name.toLowerCase().endsWith(".csv") ? "text/csv" : "application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ফাইল সংরক্ষণের অনুরোধ চালু করা যায়নি", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void chooseBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                startActivityForResult(intent, OPEN_FILE);
            });
        }
    }

    private void registerDownloadReceiver() {
        downloadReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id != activeDownloadId) return;
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
                try (Cursor c = dm.query(query)) {
                    if (c != null && c.moveToFirst()) {
                        int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            pendingApkUri = dm.getUriForDownloadedFile(id);
                            if (pendingApkUri != null) {
                                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_PENDING_URI, pendingApkUri.toString()).apply();
                                Toast.makeText(MainActivity.this, "APK ডাউনলোড সম্পন্ন হয়েছে। ইনস্টলেশন প্রস্তুত হচ্ছে…", Toast.LENGTH_LONG).show();
                                installPendingApk();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "APK ডাউনলোড সম্পন্ন হয়নি। আবার চেষ্টা করুন।", Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ডাউনলোডের অবস্থা যাচাই করা যায়নি।", Toast.LENGTH_LONG).show();
                }
            }
        };
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(downloadReceiver, filter);
    }

    private void startApkDownload(String apkUrl) {
        try {
            if (apkUrl == null || !apkUrl.startsWith("https://github.com/")) {
                Toast.makeText(this, "নিরাপদ GitHub APK লিংক পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setTitle("দৈনিক খরচের খাতা আপডেট");
            request.setDescription("নতুন সংস্করণের APK ডাউনলোড হচ্ছে…");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, "updates", "doinik-khoroch-khata-update.apk");
            activeDownloadId = dm.enqueue(request);
            Toast.makeText(this, "APK ডাউনলোড শুরু হয়েছে। নোটিফিকেশন থেকে অগ্রগতি দেখতে পারবেন।", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "ডাউনলোড শুরু করা যায়নি। ইন্টারনেট পরীক্ষা করুন।", Toast.LENGTH_LONG).show();
        }
    }

    private void installPendingApk() {
        if (pendingApkUri == null) {
            String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_PENDING_URI, null);
            if (saved != null) pendingApkUri = Uri.parse(saved);
        }
        if (pendingApkUri == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            Toast.makeText(this, "এই অ্যাপের জন্য ‘Allow from this source’ চালু করে ফিরে আসুন।", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(pendingApkUri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_PENDING_URI).apply();
            pendingApkUri = null;
        } catch (Exception e) {
            Toast.makeText(this, "Android ইনস্টলার চালু করা যায়নি। Downloads থেকে APK খুলে চেষ্টা করুন।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingApkUri != null || getSharedPreferences(PREFS, MODE_PRIVATE).contains(PREF_PENDING_URI)) installPendingApk();
    }

    @Override protected void onDestroy() {
        if (downloadReceiver != null) {
            try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_FILE && pendingFileBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open output");
                    out.write(pendingFileBytes);
                    out.flush();
                }
                pendingFileBytes = null;
                Toast.makeText(this, "ফাইল সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_FILE) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Unable to open input");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                String quoted = org.json.JSONObject.quote(json);
                webView.evaluateJavascript("window.importBackupFromAndroid(" + quoted + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "ফাইলটি পড়া বা সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
