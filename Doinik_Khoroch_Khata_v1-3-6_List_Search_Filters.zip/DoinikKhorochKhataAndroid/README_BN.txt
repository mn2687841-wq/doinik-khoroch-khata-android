দৈনিক খরচের খাতা — Android Project

বর্তমান সংস্করণ: 1.3.6

এই সংস্করণে:
- লেনদেনের তালিকায় বিবরণ ও ক্যাটাগরি দিয়ে সার্চ।
- শুরুর ও শেষ তারিখ অনুযায়ী লেনদেন ফিল্টার।
- শুধু খরচ অথবা শুধু জমা দেখার ফিল্টার।
- একাধিক ফিল্টার একসঙ্গে ব্যবহার ও রিসেট।
- আগের ক্যাটাগরি-বাজেট, দেনা-পাওনা, রিপোর্ট, ব্যাকআপ/রিস্টোর এবং অ্যাপ আপডেট সুবিধা বহাল।

Package: com.najat.doinikkhoroch
Version code: 137
Version name: 1.3.6

গুরুত্বপূর্ণ:
1. আগের APK-এর একই signing keystore ব্যবহার করতে হবে।
2. Package ID, localStorage key এবং WebView origin পরিবর্তন করা যাবে না।
3. অ্যাপের হিসাব localStorage key dailyExpenseLedgerBn_v1-এ থাকে।
4. Preferences key doinikKhorochPreferences_v1 অপরিবর্তিত রাখতে হবে।
5. APK build ও ফোনে পরীক্ষা না করে updater-কে কার্যকর ধরে নেবেন না।
6. GitHub Release-এ নতুন APK asset প্রকাশ করলে অ্যাপের updater সেটি পরীক্ষা ও ডাউনলোড করতে পারবে।
