দৈনিক খরচের খাতা — Android Project

বর্তমান সংস্করণ: 1.5.0

এই সংস্করণে:
- Official Expenses নামে আলাদা পেজ যুক্ত হয়েছে।
- Received Amount, Expenses ও Advance—প্রতিটি বিভাগে একাধিক সারি যোগ করে একসঙ্গে সেভ করা যায়।
- প্রতিটি বিভাগের এন্ট্রি-তালিকার মোট স্বয়ংক্রিয়ভাবে হিসাব হয়।
- Official Balance = Received Amount − Expenses − Advance।
- Official Expenses-এর ডেটা আলাদা localStorage key `doinikOfficialExpenses_v1`-এ সংরক্ষিত হয়।
- Official Expenses-এর জন্য আলাদা JSON Backup / Restore এবং পূর্ণ বিবরণসহ PDF/Print রিপোর্ট যুক্ত হয়েছে।
- সাধারণ অ্যাপ Backup ও Android automatic backup snapshot-এ Personal এবং Official—দুই হিসাবই অন্তর্ভুক্ত থাকে। পুরোনো ব্যাকআপে Official Ledger না থাকলে বিদ্যমান Official হিসাব মুছে ফেলা হবে না।
- Personal Expenses-এর আগের হিসাব, ফিচার, ভাষা/থিম পছন্দ ও LocalStorage key অপরিবর্তিত।
- v1.4.1: বাংলা UI-তেও তারিখ, টাকা, পরিমাণ, গণনা ও শতাংশে English digits (0–9)। Dark Mode PDF/Print সাদা পটভূমি ও কালো লেখা ব্যবহার করে।
- প্রতিদিনের স্বয়ংক্রিয় ব্যাকআপের জন্য Android WorkManager ব্যবহার।
- ফোনের নির্বাচিত ফোল্ডারে দৈনিক JSON ব্যাকআপ এবং Google Drive-এ ইন্টারনেট থাকলে ব্যাকআপ।

Package: com.najat.doinikkhoroch
Version code: 150
Version name: 1.5.0

গুরুত্বপূর্ণ:
1. প্রথমবার Settings > স্বয়ংক্রিয় ব্যাকআপ থেকে ফোনের ফোল্ডার ও Google Drive-এর ফোল্ডার নির্বাচন করতে হবে।
2. Google Drive ফোল্ডার বাছাইয়ের সময় Android folder picker-এ Google Drive খুলে My Drive-এর একটি ফোল্ডার নির্বাচন করুন।
3. ফোনের ফোল্ডার ব্যাকআপ অফলাইনেও কাজ করে। Google Drive-এ আপলোডের জন্য ইন্টারনেট দরকার।
4. Android WorkManager দৈনিক কাজ চালায়; ব্যাটারি সেভার/Android scheduling policy অনুযায়ী সুনির্দিষ্ট সময় কিছুটা পরিবর্তিত হতে পারে।
5. Package ID, Personal Ledger localStorage key এবং Preferences key অপরিবর্তিত: `com.najat.doinikkhoroch`, `dailyExpenseLedgerBn_v1`, `doinikKhorochPreferences_v1`। Official Ledger-এর আলাদা key: `doinikOfficialExpenses_v1`।
6. আগের APK-এর একই signing keystore ব্যবহার করতে হবে।
7. APK build ও বাস্তব Android ফোনে পরীক্ষা না করে ব্যাকআপ বা PDF-কে সফল ধরে নেবেন না।
8. v1.5.0 প্রথম ইনস্টল/আপডেটের আগে Personal ও Official—দুই ধরনের হিসাবের আলাদা ও পূর্ণ ব্যাকআপ রেখে নিন।
