দৈনিক খরচের খাতা — Android Studio প্রজেক্ট
===========================================

এই প্যাকেজে আপনার খরচের খাতার সর্বশেষ HTML সংস্করণটি Android অ্যাপের ভিতরে যুক্ত করা হয়েছে।
অ্যাপটি অফলাইনে চলার জন্য তৈরি; হিসাব WebView-এর local storage-এ সংরক্ষিত হবে।

গুরুত্বপূর্ণ:
- এটি Android Studio-তে খুলে APK তৈরি করার সোর্স প্রজেক্ট; APK ফাইল নিজে নয়।
- এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে সরাসরি APK কম্পাইল করা যায়নি।
- ফোন বদলালে বা অ্যাপের ডেটা মুছে গেলে হিসাব হারাতে পারে। অ্যাপের ব্যাকআপ সুবিধা ব্যবহার করুন।

APK তৈরি:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে "Open" নির্বাচন করে এই ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. তৈরি APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।
6. APK ফোনে পাঠিয়ে ইনস্টল করুন। ফোনে প্রয়োজনে "Install unknown apps" অনুমতি দিতে হবে।

অ্যাপের নাম: দৈনিক খরচের খাতা
Application ID: com.najat.doinikkhoroch
Version: 1.0
