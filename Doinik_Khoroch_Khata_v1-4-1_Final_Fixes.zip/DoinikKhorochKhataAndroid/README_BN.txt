দৈনিক খরচের খাতা — Android Project

বর্তমান সংস্করণ: 1.4.1

এই সংস্করণে:
- v1.4.1: বাংলা UI-তেও তারিখ, টাকা, পরিমাণ, গণনা ও শতাংশে English digits (0–9)।
- Dark Mode থেকে PDF/Print করলে সব পৃষ্ঠা সাদা পটভূমি ও কালো লেখায় প্রিন্ট হবে।
- Dark Mode-এর লেখা, ইনপুট, টেবিল, বাটন ও সহায়ক লেখার কনট্রাস্ট উন্নত।
- v1.3.7 Dashboard, নেভিগেশন ও ফিল্টার করা খরচের মোট অপরিবর্তিত।
- প্রতিদিনের স্বয়ংক্রিয় ব্যাকআপের জন্য Android WorkManager ব্যবহার।
- ফোনের নির্বাচিত ফোল্ডারে দৈনিক JSON ব্যাকআপ।
- Google Drive-এর নির্বাচিত ফোল্ডারে ইন্টারনেট সংযোগ থাকলে দৈনিক ব্যাকআপ।
- হিসাব পরিবর্তনের পর Drive-এ আপলোডের জন্য অপেক্ষমাণ ব্যাকআপ কাজ।
- ব্যাকআপে লেনদেন, ক্যাটাগরি, বাজেট, দেনা-পাওনা ও অ্যাপের পছন্দ সংরক্ষণ।
- ম্যানুয়াল ব্যাকআপ এখন নতুন envelope format-এ; আগের JSON ব্যাকআপও Restore করা যাবে।
- Settings থেকে ফোন ও Google Drive—দুই ফোল্ডার নির্বাচন এবং এখনই ব্যাকআপ চালানোর ব্যবস্থা।

Package: com.najat.doinikkhoroch
Version code: 141
Version name: 1.4.1

গুরুত্বপূর্ণ:
1. প্রথমবার Settings > স্বয়ংক্রিয় ব্যাকআপ থেকে ফোনের ফোল্ডার ও Google Drive-এর ফোল্ডার নির্বাচন করতে হবে।
2. Google Drive ফোল্ডার বাছাইয়ের সময় Android folder picker-এ Google Drive খুলে My Drive-এর একটি ফোল্ডার নির্বাচন করুন। Google Drive-এর Android DocumentsProvider উপলভ্য থাকতে হবে।
3. ফোনের ফোল্ডার ব্যাকআপ অফলাইনেও কাজ করে। Google Drive-এ আপলোডের জন্য ইন্টারনেট দরকার।
4. Android WorkManager দৈনিক কাজ চালায়; ব্যাটারি সেভার/Android scheduling policy অনুযায়ী সুনির্দিষ্ট সময় কিছুটা পরিবর্তিত হতে পারে।
5. Package ID, localStorage key এবং WebView origin অপরিবর্তিত: com.najat.doinikkhoroch, dailyExpenseLedgerBn_v1 এবং doinikKhorochPreferences_v1।
6. আগের APK-এর একই signing keystore ব্যবহার করতে হবে।
7. APK build ও ফোনে পরীক্ষা না করে ব্যাকআপকে সফল ধরে নেবেন না।


v1.4.1-এ Settings থেকে বাংলা/English এবং Light/Dark Mode নির্বাচন করা যায়। পছন্দ doinikKhorochPreferences_v1-এ সংরক্ষিত থাকে। Print/PDF উভয় থিমেই সাদা পটভূমি ও স্পষ্ট কালো লেখা ব্যবহার করে।

- আপডেট ডাউনলোড শেষ হলে Download notification থেকে APK খুলে নিজে ইনস্টল করতে হবে; অ্যাপ স্বয়ংক্রিয়ভাবে ইনস্টলার চালু করে না।
- REQUEST_INSTALL_PACKAGES permission ব্যবহার করা হয় না।
