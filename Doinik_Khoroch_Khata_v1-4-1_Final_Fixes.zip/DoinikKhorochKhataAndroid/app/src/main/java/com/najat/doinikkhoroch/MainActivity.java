package com.najat.doinikkhoroch;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Build;
import android.provider.DocumentsContract;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.File;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 401;
    private static final int OPEN_FILE = 402;
    private static final int PICK_PHONE_BACKUP_FOLDER = 403;
    private static final int PICK_DRIVE_BACKUP_FOLDER = 404;
    private WebView webView;
    private String pendingFileName;
    private byte[] pendingFileBytes;
    private long activeDownloadId = -1;
    private BroadcastReceiver downloadReceiver;

    private String uiText(String bn, String en) {
        return "en".equals(getSharedPreferences("ui_preferences", MODE_PRIVATE).getString("language", "bn")) ? en : bn;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerDownloadReceiver();
        BackupScheduler.scheduleDaily(this);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF101827);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppBridge(this), "AndroidApp");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AppBridge {
        private final Context context;
        AppBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void setUiLanguage(String language) {
            getSharedPreferences("ui_preferences", MODE_PRIVATE).edit()
                    .putString("language", "en".equals(language) ? "en" : "bn").apply();
        }

        @JavascriptInterface
        public void openCalculator() {
            ((Activity) context).runOnUiThread(() -> {
                Intent calculatorIntent = new Intent(Intent.ACTION_MAIN);
                calculatorIntent.addCategory("android.intent.category.APP_CALCULATOR");
                calculatorIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    if (calculatorIntent.resolveActivity(getPackageManager()) != null) {
                        startActivity(calculatorIntent);
                        return;
                    }
                    String[] calculatorPackages = {
                        "com.google.android.calculator",
                        "com.android.calculator2",
                        "com.sec.android.app.popupcalculator"
                    };
                    for (String packageName : calculatorPackages) {
                        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                        if (launchIntent != null) {
                            startActivity(launchIntent);
                            return;
                        }
                    }
                    Toast.makeText(context, MainActivity.this.uiText("এই ফোনে ক্যালকুলেটর অ্যাপ খুঁজে পাওয়া যায়নি।", "No calculator app was found on this phone."), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(context, MainActivity.this.uiText("ক্যালকুলেটর চালু করা যায়নি।", "Could not open the calculator."), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void checkForUpdate(String callbackName) {
            // Always report a visible result to the WebView, including when no GitHub
            // Release has been published yet. Never silently leave the button spinning.
            new Thread(() -> {
                String result;
                HttpURLConnection connection = null;
                try {
                    URL url = new URL("https://api.github.com/repos/mn2687841-wq/doinik-khoroch-khata-android/releases/latest");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("User-Agent", "Doinik-Khoroch-Khata-Android");
                    int code = connection.getResponseCode();
                    org.json.JSONObject response = new org.json.JSONObject();
                    if (code == 404) {
                        response.put("error", "এখনো GitHub-এ নতুন সংস্করণের Release প্রকাশ করা হয়নি। Release প্রকাশের পর আবার পরীক্ষা করুন।");
                    } else if (code != 200) {
                        response.put("error", "GitHub থেকে তথ্য পাওয়া যায়নি (HTTP " + code + ")। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");
                    } else {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (InputStream in = connection.getInputStream()) {
                            byte[] buffer = new byte[4096]; int n;
                            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        }
                        org.json.JSONObject release = new org.json.JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
                        String tag = release.optString("tag_name", "").replaceFirst("^[vV]", "");
                        String releaseUrl = release.optString("html_url", "https://github.com/mn2687841-wq/doinik-khoroch-khata-android/releases/latest");
                        response.put("version", tag);
                        response.put("url", releaseUrl);
                        String apkUrl = "";
                        org.json.JSONArray assets = release.optJSONArray("assets");
                        if (assets != null) {
                            for (int i = 0; i < assets.length(); i++) {
                                org.json.JSONObject asset = assets.optJSONObject(i);
                                if (asset != null && asset.optString("name").toLowerCase().endsWith(".apk")) {
                                    apkUrl = asset.optString("browser_download_url");
                                    break;
                                }
                            }
                        }
                        response.put("apkUrl", apkUrl);
                        String currentVersion = BuildConfig.VERSION_NAME;
                        response.put("currentVersion", currentVersion);
                        response.put("available", !apkUrl.isEmpty() && isNewerVersion(tag, currentVersion));
                        if (apkUrl.isEmpty()) response.put("error", "সর্বশেষ Release-এ APK ফাইল পাওয়া যায়নি।");
                        else if (!response.optBoolean("available")) response.put("message", "আপনার অ্যাপ সর্বশেষ প্রকাশিত সংস্করণে আছে (" + currentVersion + ")।");
                    }
                    result = response.toString();
                } catch (Exception e) {
                    try { result = new org.json.JSONObject().put("error", "আপডেট পরীক্ষা করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।").toString(); }
                    catch (Exception ignored) { result = "{}"; }
                } finally { if (connection != null) connection.disconnect(); }
                final String json = result;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.showUpdateResult(" + org.json.JSONObject.quote(json) + ")", null);
                });
            }).start();
        }

        @JavascriptInterface
        public void downloadUpdate(String apkUrl) {
            runOnUiThread(() -> startApkDownload(apkUrl));
        }

        private boolean isNewerVersion(String latest, String current) {
            try {
                String[] a = latest.split("\\."), b = current.split("\\.");
                for (int i = 0; i < Math.max(a.length, b.length); i++) {
                    int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9].*$", "")) : 0;
                    int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9].*$", "")) : 0;
                    if (x != y) return x > y;
                }
            } catch (Exception ignored) { }
            return false;
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    String printTitle = webView.getTitle();
                    if (printTitle == null || printTitle.trim().isEmpty()) printTitle = "DoinikKhorochKhata";
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(printTitle);
                    pm.print(printTitle, adapter,
                        new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, uiText("প্রিন্ট চালু করা যায়নি", "Could not start printing."), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String base64) {
            runOnUiThread(() -> {
                try {
                    pendingFileName = name;
                    pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(name.toLowerCase().endsWith(".csv") ? "text/csv" : "application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, uiText("ফাইল সংরক্ষণের অনুরোধ চালু করা যায়নি", "Could not start the file save request."), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void chooseBackupFolder(String target) {
            runOnUiThread(() -> {
                try {
                    boolean drive = "drive".equals(target);
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, drive ? PICK_DRIVE_BACKUP_FOLDER : PICK_PHONE_BACKUP_FOLDER);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, uiText("ফোল্ডার নির্বাচন চালু করা যায়নি।", "Could not open the folder picker."), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBackupSnapshot(String json) {
            try {
                if (json == null || json.length() == 0) return;
                File target = new File(getFilesDir(), AutoBackupWorker.SNAPSHOT_FILE);
                File temp = new File(getFilesDir(), AutoBackupWorker.SNAPSHOT_FILE + ".tmp");
                try (FileOutputStream out = new FileOutputStream(temp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    out.getFD().sync();
                }
                if (target.exists() && !target.delete()) throw new Exception("Old snapshot could not be replaced");
                if (!temp.renameTo(target)) throw new Exception("Snapshot could not be saved");
                if (getSharedPreferences(AutoBackupWorker.PREFS, MODE_PRIVATE)
                        .contains(AutoBackupWorker.DRIVE_TREE)) {
                    BackupScheduler.syncDriveWhenOnline(MainActivity.this);
                }
            } catch (Exception e) {
                getSharedPreferences(AutoBackupWorker.PREFS, MODE_PRIVATE).edit()
                        .putString(AutoBackupWorker.STATUS, "নতুন ব্যাকআপ কপি প্রস্তুত করা যায়নি।").apply();
            }
        }

        @JavascriptInterface
        public String getBackupStatus() {
            android.content.SharedPreferences p = getSharedPreferences(AutoBackupWorker.PREFS, MODE_PRIVATE);
            String phone = p.getString(AutoBackupWorker.LAST_PHONE, "এখনো হয়নি");
            String drive = p.getString(AutoBackupWorker.LAST_DRIVE, "এখনো হয়নি");
            String status = p.getString(AutoBackupWorker.STATUS, "প্রতিদিন স্বয়ংক্রিয় ব্যাকআপ চালু আছে।");
            String phoneFolder = p.contains(AutoBackupWorker.PHONE_TREE) ? "ফোল্ডার নির্বাচিত" : "ফোল্ডার নির্বাচন বাকি";
            String driveFolder = p.contains(AutoBackupWorker.DRIVE_TREE) ? "ফোল্ডার নির্বাচিত" : "ফোল্ডার নির্বাচন বাকি";
            return "ফোন (" + phoneFolder + "): " + phone + " | Google Drive (" + driveFolder + "): " + drive + " | " + status;
        }

        @JavascriptInterface
        public void runBackupNow() {
            runOnUiThread(() -> {
                BackupScheduler.runNow(MainActivity.this);
                Toast.makeText(MainActivity.this, uiText("ব্যাকআপের কাজ শুরু হয়েছে।", "Backup has started."), Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface
        public void chooseBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                startActivityForResult(intent, OPEN_FILE);
            });
        }
    }

    private void registerDownloadReceiver() {
        downloadReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id != activeDownloadId) return;
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
                try (Cursor c = dm.query(query)) {
                    if (c != null && c.moveToFirst()) {
                        int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            Toast.makeText(MainActivity.this, uiText(
                                    "APK ডাউনলোড সম্পন্ন হয়েছে। ইনস্টল করতে নোটিফিকেশনে ট্যাপ করুন।",
                                    "APK download completed. Tap the download notification to open and install it manually."
                            ), Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, uiText("APK ডাউনলোড সম্পন্ন হয়নি। আবার চেষ্টা করুন।", "APK download failed. Please try again."), Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, uiText("ডাউনলোডের অবস্থা যাচাই করা যায়নি।", "Could not check the download status."), Toast.LENGTH_LONG).show();
                }
            }
        };
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(downloadReceiver, filter);
    }

    private void startApkDownload(String apkUrl) {
        try {
            if (apkUrl == null || !apkUrl.startsWith("https://github.com/")) {
                Toast.makeText(this, uiText("নিরাপদ GitHub APK লিংক পাওয়া যায়নি।", "A verified GitHub APK link was not found."), Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setTitle("দৈনিক খরচের খাতা আপডেট");
            request.setDescription("নতুন সংস্করণের APK ডাউনলোড হচ্ছে…");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, "updates", "doinik-khoroch-khata-update.apk");
            activeDownloadId = dm.enqueue(request);
            Toast.makeText(this, uiText("APK ডাউনলোড শুরু হয়েছে। নোটিফিকেশন থেকে অগ্রগতি দেখতে পারবেন।", "APK download started. You can check progress in notifications."), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, uiText("ডাউনলোড শুরু করা যায়নি। ইন্টারনেট পরীক্ষা করুন।", "Could not start the download. Check your internet connection."), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.evaluateJavascript("window.refreshBackupStatus && window.refreshBackupStatus()", null);
    }

    @Override protected void onDestroy() {
        if (downloadReceiver != null) {
            try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == PICK_PHONE_BACKUP_FOLDER || requestCode == PICK_DRIVE_BACKUP_FOLDER) {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
                boolean drive = requestCode == PICK_DRIVE_BACKUP_FOLDER;
                String key = drive ? AutoBackupWorker.DRIVE_TREE : AutoBackupWorker.PHONE_TREE;
                getSharedPreferences(AutoBackupWorker.PREFS, MODE_PRIVATE).edit().putString(key, uri.toString()).apply();
                BackupScheduler.scheduleDaily(this);
                BackupScheduler.runNow(this);
                Toast.makeText(this, drive ? uiText("Google Drive ব্যাকআপ ফোল্ডার সেট হয়েছে।", "Google Drive backup folder has been set.") : uiText("ফোনের ব্যাকআপ ফোল্ডার সেট হয়েছে।", "Phone backup folder has been set."), Toast.LENGTH_LONG).show();
                if (webView != null) webView.evaluateJavascript("window.refreshBackupStatus && window.refreshBackupStatus()", null);
            } else if (requestCode == CREATE_FILE && pendingFileBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open output");
                    out.write(pendingFileBytes);
                    out.flush();
                }
                pendingFileBytes = null;
                Toast.makeText(this, uiText("ফাইল সংরক্ষণ হয়েছে", "File saved."), Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_FILE) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Unable to open input");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                String quoted = org.json.JSONObject.quote(json);
                webView.evaluateJavascript("window.importBackupFromAndroid(" + quoted + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, uiText("ফাইলটি পড়া বা সংরক্ষণ করা যায়নি", "Could not read or save the file."), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
